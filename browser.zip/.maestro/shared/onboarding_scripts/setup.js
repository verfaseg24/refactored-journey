output.onboarding = {
    runFullOnboarding: true
}