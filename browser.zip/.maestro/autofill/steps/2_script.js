output.addLogins = {
    domains: ["https://a.example.com", "fill.dev/example", "192.168.0.100"],
    counter: 0
}
